# wallop — a VRG game

Free to copy, remix and republish under LICENSE.md. The one condition: keep a visible
"A VRG game" credit linking to https://arcade.vrg.li.

- `game/` is the browser client; open `game/index.html` from any static server.


- The price feed is a seeded simulation (`game/js/engine.js`); a real one needs a server that settles rounds on a live BTC price.
