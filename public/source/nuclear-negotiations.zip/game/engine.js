/* Nuclear Negotiations — table engine. No DOM, so the same rules can run on a server later.
 *
 * Two wheels of four seats. Positions go clockwise from top-left: 0,1,2,3.
 * Outer seats are lettered A B D C (A top-left, B top-right, D bottom-right, C bottom-left);
 * inner seats are numbered 1 2 4 3 the same way, so A faces 1, B faces 2, C faces 3, D faces 4.
 * Seat labels are fixed to the table; leaders move through them.
 *
 * Standard mode: a move swaps a rogue leader with the leader facing it on the other wheel,
 * then the outer wheel turns one seat clockwise. If that leaves the two rogues facing each
 * other, it is nuclear war and whoever made the move loses.
 */
(function (root) {
  'use strict';
  var LEADERS = [
    { id: 'don', nm: 'Don' }, { id: 'vlad', nm: 'Vlad' }, { id: 'ursula', nm: 'Ursula' }, { id: 'zel', nm: 'Zel' },
    { id: 'modi', nm: 'Modi' }, { id: 'bibi', nm: 'Bibi' }, { id: 'obama', nm: 'Obama' }, { id: 'mbs', nm: 'MBS' },
  ];
  var OUTER = ['A', 'B', 'D', 'C'], INNER = ['1', '2', '4', '3'];
  // The rhythm, in spells of SPELL moves: an opening at 3 s a move, then HURRY UP at 1 s, then
  // ESCALATION (a third leader goes rogue, still 1 s), then HURRY UP again with the third rogue
  // standing down, then ESCALATION again, and so on until the war.
  var SPELL = 6, CLOCK = { open: 3000, hurry: 1000, escalation: 1000 };
  function phase(m) { return m < SPELL ? 'open' : Math.floor((m - SPELL) / SPELL) % 2 ? 'escalation' : 'hurry'; }
  function clockMs(m) { return CLOCK[phase(m)]; }

  // Small seeded PRNG (mulberry32) so a game can be replayed from its seed.
  function rng(seed) { var a = seed >>> 0; return function () { a |= 0; a = a + 0x6D2B79F5 | 0; var t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }

  function newGame(seed) {
    if (seed == null) seed = (Math.random() * 4294967296) >>> 0;
    var r = rng(seed), ids = LEADERS.map(function (l) { return l.id; });
    for (var i = ids.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)); var t = ids[i]; ids[i] = ids[j]; ids[j] = t; }
    var ro = Math.floor(r() * 4), ri = Math.floor(r() * 3); if (ri >= ro) ri++;   // never facing
    return { seed: seed, outer: ids.slice(0, 4), inner: ids.slice(4, 8), rogue: {}, rogueOuter: ro, rogueInner: ri, moves: 0, ks: [], extra: null, log: [], over: false, turns: 0 };
  }
  // Rogue reveal: fix which two leaders are rogue (the leaders carry it, not the seats).
  function reveal(g) { g.rogue[g.outer[g.rogueOuter]] = true; g.rogue[g.inner[g.rogueInner]] = true; g.log.push('reveal ' + rogues(g)); return g; }

  function rogues(g) {
    var s = [];
    for (var k = 0; k < 4; k++) { if (g.rogue[g.outer[k]]) s.push(OUTER[k] + '*'); if (g.rogue[g.inner[k]]) s.push(INNER[k] + '*'); }
    return s.join(' ');
  }
  function war(g) { for (var k = 0; k < 4; k++) if (g.rogue[g.outer[k]] && g.rogue[g.inner[k]]) return k; return -1; }
  // Legal moves: every position holding exactly one rogue (both would already be war).
  function legal(g) { var m = []; if (g.over) return m; for (var k = 0; k < 4; k++) if (g.rogue[g.outer[k]] || g.rogue[g.inner[k]]) m.push(k); return m; }
  function notation(g, k) { return OUTER[k] + (g.rogue[g.outer[k]] ? '*' : '') + '<->' + INNER[k] + (g.rogue[g.inner[k]] ? '*' : ''); }
  // Would playing position k end in war? (Lets a trainer or an AI tell a blunder from a safe move.)
  function fatal(g, k) { var c = clone(g); apply(c, k); return c.over; }

  function apply(g, k) {
    if (g.over || legal(g).indexOf(k) < 0) return null;
    var line = notation(g, k);
    var t = g.outer[k]; g.outer[k] = g.inner[k]; g.inner[k] = t;             // the swap
    g.outer = [g.outer[3], g.outer[0], g.outer[1], g.outer[2]];               // outer turns one seat clockwise
    g.turns++; g.moves++; g.ks.push(k);
    var w = war(g); g.over = w >= 0;
    g.log.push(g.moves + '. ' + line + ' -> ' + (g.over ? 'NUCLEAR WAR at ' + OUTER[w] + '/' + INNER[w] : rogues(g)));
    return { move: line, war: w };
  }
  // Escalation: one more leader goes rogue. Never one already facing a rogue (instant war), and
  // when possible one that still leaves the player a safe move. Returns the seat label, or null.
  // The pick is seeded by the game and the move number, so a replay picks the same leader.
  function escalate(g, r) {
    r = r || rng((g.seed ^ Math.imul(g.moves + 1, 0x9E3779B1)) >>> 0);
    var c = [], k;
    for (k = 0; k < 4; k++) {
      if (!g.rogue[g.outer[k]] && !g.rogue[g.inner[k]]) { c.push({ id: g.outer[k], lbl: OUTER[k] }); c.push({ id: g.inner[k], lbl: INNER[k] }); }
    }
    if (!c.length) return null;
    var ok = c.filter(function (x) { var t = clone(g); t.rogue[x.id] = true; return legal(t).some(function (m) { return !fatal(t, m); }); });
    var pick = (ok.length ? ok : c)[Math.floor(r() * (ok.length ? ok : c).length)];
    g.rogue[pick.id] = true; g.log.push('escalation ' + pick.lbl + '* -> ' + rogues(g));
    return pick;
  }
  // Replay a finished game from its seed and the positions played (g.ks). Returns the final
  // state, or null if a move was illegal, the game went on after the war, or never ended.
  function replay(seed, ks) {
    if (!Array.isArray(ks)) return null;
    var g = reveal(newGame(seed >>> 0));
    for (var i = 0; i < ks.length; i++) {
      if (g.over || !apply(g, ks[i])) return null;
      after(g);
    }
    return g.over ? g : null;
  }
  // After a move, when the phase turns: ESCALATION brings a third rogue in, the next HURRY UP
  // sends that one back. Returns { escalate: pick }, { calm: id } or null.
  function after(g) {
    if (g.over || g.moves < SPELL) return null;
    var was = phase(g.moves - 1), now = phase(g.moves);
    if (was === now) return null;
    if (now === 'escalation') { var pick = escalate(g); if (!pick) return null; g.extra = pick.id; return { escalate: pick }; }
    if (was === 'escalation' && g.extra) {
      var id = g.extra; delete g.rogue[id]; g.extra = null;
      g.log.push('de-escalation ' + NN.name(id) + ' stands down -> ' + rogues(g));
      return { calm: id };
    }
    return null;
  }
  function clone(g) { return JSON.parse(JSON.stringify(g)); }
  function logText(g) { return ['Nuclear Negotiations · seed ' + g.seed, 'outer A ' + g.outer[0] + ' B ' + g.outer[1] + ' D ' + g.outer[2] + ' C ' + g.outer[3] + ' (now)', 'inner 1 ' + g.inner[0] + ' 2 ' + g.inner[1] + ' 4 ' + g.inner[2] + ' 3 ' + g.inner[3]].concat(g.log).join('\n'); }

  var NN = { LEADERS: LEADERS, OUTER: OUTER, INNER: INNER, SPELL: SPELL, phase: phase, clockMs: clockMs, after: after, newGame: newGame, replay: replay, reveal: reveal, escalate: escalate, legal: legal, apply: apply, fatal: fatal, war: war, rogues: rogues, notation: notation, logText: logText, name: function (id) { for (var i = 0; i < LEADERS.length; i++) if (LEADERS[i].id === id) return LEADERS[i].nm; return id; } };
  if (root.exports) root.exports = NN; else root.NN = NN;
})(typeof module !== 'undefined' ? module : window);
