# nuclear-negotiations — a VRG game

Free to copy, remix and republish under LICENSE.md. The one condition: keep a visible
"A VRG game" credit linking to https://play.vrg.li.

- `game/` is the browser client; open `game/index.html` from any static server.

- The rules are in `game/engine.js`, free of any DOM code, so an AI or a server can drive the same table.

